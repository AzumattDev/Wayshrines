> ### Version 1.1.2
> - Update for Valheim 0.217.22 (Updated ServerSync)
> ### Version 1.1.1
> - Update for Hildir's Request (0.217.14)
> ### Version 1.1.0
> * Much needed updates.
> * Truth be told, most of the code changes have been sitting here for over a year. I just never got around to releasing
    them. So, I barely remember what I changed.
> ### Version 1.0.6
> * Complete re-write of code. Should be fixed for Hearth and Home, other mod compatibility, and known error from 1.0.5
    fixed.
> * Admin command moved to H&H methods of doing them. delway in console or /delway in chat to delete all Wayshrines
    found in the world.
> * I lost some of the original Unity project and had to rebuild the assets, so there might be some texture/particle
    differences.
> * I removed the spawn that config file in this version as I don't know how good that file is anymore. Feel free to
    make and provide one if you wish. I'll include it in future downloads.
> ### Version 1.0.5
> * More singleplayer fixes
> * Customize shout message
> * Map pin fixes for Multiplayer and Singleplayer
> * Additional Wayshrine added
> * Map pins now specific to Wayshrine
> * NOTE: Known error output on entering the skull Wayshrine's collider for teleport
> ### Version 1.0.4
> * Single player FPS issue fixed. Map pins are a little broken, they do not update automatically like they do in
    Multiplayer. Not sure why, working on fixes.
> * Admin command to remove ALL wayshrines from the world regardless of distance or owner. Use !delway or !
    deletewayshrines in the console. Will work to add this to chat, testing with VChat when using the command caused
    game crashes after the latest game update.
> * Config options added
> * General refactoring of code with some optimizations.
> ### Version 1.0.3
> * Fixed bug that causes issues with Jotunn mod's recipes
> ### Version 1.0.2
> * NOTE: Feel free to upload your own pictures and videos of this mod to the mod page!
> * Wayshrine_Skull added, has double functionality for original and world wayshrine teleports. Interact for
    original..walk onto skull for world teleport
> * Config options added. Server admins can change configs while on the server using configuration managers, no need for
    reboots
> * Wayshrines are now linked together. Interact with them to choose one on the map. Map pins will periodically update
    if they don't immediately show when a wayshrine spawns/is placed.
> * Wayshrines have visual changes to begin reflecting biomes in a better manner
> * Assets reduced in size to help with file size overall.
> * Custom bifrost effect with thunderclap sound on teleport